package Main;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class Recharge extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JButton button;

	/**
	 * Launch the application.
	 */
	
			public void run() {
				try {
					Recharge frame = new Recharge();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public Recharge() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(123, 68, 175, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setText("   \u5145\u503C\u91D1\u989D");
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(28, 72, 66, 21);
		contentPane.add(textField_1);
		
		button = new JButton("\u5145\u503C");
		button.addActionListener(this);
		button.setBounds(155, 134, 93, 23);
		contentPane.add(button);
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==button)
		{
			int recharge=Integer.parseInt(textField.getText());
			Test.customer.setAccount(Test.customer.getAccount()+recharge);
			String msg="��ֵ�ɹ�";
			String title="��ʾ";
			JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
			this.dispose();
			SellPage2014302580073 nsellpage=new SellPage2014302580073();
			nsellpage.run();
		}
	}

}
