package Main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import pojo.Customer;
import pojo.Pet;

public class ConnectSQL {
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	public Connection getConnection() 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url);
			return conn;
		}
        catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	public ArrayList<Pet> readPet() 
	{
		ArrayList<Pet> list=new ArrayList<Pet>();
		try 
		{
			Connection con=getConnection();
			PreparedStatement ps;
			ps = con.prepareStatement("select * from 2014302580073_pet");
			ResultSet rs  =  ps.executeQuery();//ִ�в�ѯ
			while(rs.next())
			{
			  Pet data=new Pet();
			  data.setName(rs.getString(2));
			  data.setEat(rs.getString(3));
			  data.setDrink(rs.getString(4));
			  data.setLive(rs.getString(5));
			  data.setHobby(rs.getString(6));
			  data.setPrice(rs.getInt(7));
			  list.add(data);
			  //System.out.println(rs.getString(4));
			}
			
			con.close();
			return list;
		} 
		catch (SQLException e) 
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			return null;
		}//����������
	}
	public ArrayList<Customer> readCustomer() 
	{
		ArrayList<Customer> list=new ArrayList<Customer>();
		try 
		{
			Connection con=getConnection();
			PreparedStatement ps;
			ps = con.prepareStatement("select * from 2014302580073_customer");
			ResultSet rs  =  ps.executeQuery();//ִ�в�ѯ
			while(rs.next())
			{
			  Customer data=new Customer(); 
			  data.setName(rs.getString(2));
			  data.setSex(rs.getString(3));
			  data.setPhoneNumber(rs.getString(4));
			  data.setEmail(rs.getString(5));
			  data.setIid(rs.getString(6));
			  data.setAccount(Integer.parseInt(rs.getString(7)));
			  data.setPassword(rs.getString(8));
			  list.add(data);
			  //System.out.println(rs.getString(4));
			}
			
			con.close();
			return list;
		} 
		catch (SQLException e) 
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			return null;
		}//����������
	}

}
