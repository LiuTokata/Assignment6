package Main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Pet;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class SellPage2014302580073 extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JButton btnNewButton_9;
	private JButton btnNewButton_10;
	private JButton btnNewButton_11;
	private JButton btnNewButton_12;
	GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
	static ConnectSQL connpet=new ConnectSQL();
	static ArrayList<Pet> petList=connpet.readPet();
	private JButton btnNewButton_13;

	/**
	 * Launch the application.
	 */
	
			public void run() 
			{
				try {
					SellPage2014302580073 frame = new SellPage2014302580073();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public SellPage2014302580073() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnNewButton = new JButton("Dog");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(25, 10, 93, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Cat");
		btnNewButton_1.addActionListener(this);
		btnNewButton_1.setBounds(25, 71, 93, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Turtle");
		btnNewButton_2.addActionListener(this);
		btnNewButton_2.setBounds(25, 132, 93, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("Hamster");
		btnNewButton_3.addActionListener(this);
		btnNewButton_3.setBounds(169, 10, 93, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("Squirrel");
		btnNewButton_4.addActionListener(this);
		btnNewButton_4.setBounds(169, 71, 93, 23);
		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("Rabbit");
		btnNewButton_5.addActionListener(this);
		btnNewButton_5.setBounds(169, 132, 93, 23);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("Lizard");
		btnNewButton_6.addActionListener(this);
		btnNewButton_6.setBounds(317, 10, 93, 23);
		contentPane.add(btnNewButton_6);
		
		btnNewButton_7 = new JButton("Fish");
		btnNewButton_7.addActionListener(this);
		btnNewButton_7.setBounds(317, 71, 93, 23);
		contentPane.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("Myna");
		btnNewButton_8.addActionListener(this);
		btnNewButton_8.setBounds(317, 132, 93, 23);
		contentPane.add(btnNewButton_8);
		
		btnNewButton_9 = new JButton("Parrot");
		btnNewButton_9.addActionListener(this);
		btnNewButton_9.setBounds(25, 197, 93, 23);
		contentPane.add(btnNewButton_9);
		
		btnNewButton_10 = new JButton("Snake");
		btnNewButton_10.addActionListener(this);
		btnNewButton_10.setBounds(169, 197, 93, 23);
		contentPane.add(btnNewButton_10);
		
		btnNewButton_11 = new JButton("Canary");
		btnNewButton_11.addActionListener(this);
		btnNewButton_11.setBounds(317, 197, 93, 23);
		contentPane.add(btnNewButton_11);
		
		btnNewButton_12 = new JButton("\u767B\u51FA");
		btnNewButton_12.addActionListener(this);
		btnNewButton_12.setBounds(169, 238, 93, 23);
		contentPane.add(btnNewButton_12);
		
		btnNewButton_13 = new JButton("\u5145\u503C");
		btnNewButton_13.addActionListener(this);
		btnNewButton_13.setBounds(25, 238, 93, 23);
		contentPane.add(btnNewButton_13);
	}
	public void actionPerformed(ActionEvent e) 
	{
		
		if(e.getSource()==btnNewButton)
		{
			
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(0);
			//System.out.println(petList.get(0).getName());
			GoodsMessageShow2014302580073.goodsid=0;
			show.run();
		}
		else if(e.getSource()==btnNewButton_1)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(1);
			GoodsMessageShow2014302580073.goodsid=1;
			show.run();
		}
		else if(e.getSource()==btnNewButton_2)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(2);
			GoodsMessageShow2014302580073.goodsid=2;
			show.run();
		}
		else if(e.getSource()==btnNewButton_3)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(3);
			GoodsMessageShow2014302580073.goodsid=3;
			show.run();
		}
		else if(e.getSource()==btnNewButton_4)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(4);
			GoodsMessageShow2014302580073.goodsid=4;
			show.run();
		}
		else if(e.getSource()==btnNewButton_5)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(5);
			GoodsMessageShow2014302580073.goodsid=5;
			show.run();
		}
		else if(e.getSource()==btnNewButton_6)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(6);
			GoodsMessageShow2014302580073.goodsid=6;
			show.run();
		}
		else if(e.getSource()==btnNewButton_7)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(7);
			GoodsMessageShow2014302580073.goodsid=7;
			show.run();
		}
		else if(e.getSource()==btnNewButton_8)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(8);
			GoodsMessageShow2014302580073.goodsid=8;
			show.run();
		}
		else if(e.getSource()==btnNewButton_9)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(9);
			GoodsMessageShow2014302580073.goodsid=9;
			show.run();
		}
		else if(e.getSource()==btnNewButton_10)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(10);
			GoodsMessageShow2014302580073.goodsid=10;
			show.run();
		}
		else if(e.getSource()==btnNewButton_11)
		{
			//GoodsMessageShow2014302580073 show=new GoodsMessageShow2014302580073();
			this.dispose();
			GoodsMessageShow2014302580073.pet=petList.get(11);
			GoodsMessageShow2014302580073.goodsid=11;
			show.run();
		}
		else if(e.getSource()==btnNewButton_12)
		{
			this.dispose();
			Test.main();
		}
		else if(e.getSource()==btnNewButton_13)
		{
			this.dispose();
			Recharge recharge=new Recharge();
			recharge.run();
		}
		else{
			System.out.println("��������");
		}
	}
}
