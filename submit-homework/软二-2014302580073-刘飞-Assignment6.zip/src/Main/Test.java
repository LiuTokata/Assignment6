package Main;

import pojo.Customer;

public class Test {
	
	//static UserServiceImpl userservice=new UserServiceImpl();
	static Customer customer=new Customer();
	
	public static void main(String[] args) 
	{
		Log2014302580073 login=new Log2014302580073();
		login.run();

	}
	public static void main()
	{
		Log2014302580073 login=new Log2014302580073();
		login.run();

	}

}
