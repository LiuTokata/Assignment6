package Main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Customer;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

@SuppressWarnings("serial")
public class Log2014302580073 extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_2;
	private JButton button;
	private JButton button_1;
	String id;
	String password;
	Register2014302580073 newregister;
	SellPage2014302580073 sellpage;
	private JTextField textField_1;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	
			public void run() {
				try {
					Log2014302580073 frame = new Log2014302580073();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
	

	/**
	 * Create the frame.
	 */
	public Log2014302580073() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		button = new JButton("\u767B\u5F55");
		button.addActionListener(this);
		button.setBounds(166, 161, 93, 23);
		contentPane.add(button);
		
		button_1 = new JButton("\u6CE8\u518C");
		button_1.addActionListener(this); 
		button_1.setBounds(166, 203, 93, 23);
		contentPane.add(button_1);
		
		textField = new JTextField();
		textField.setBounds(132, 91, 159, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setText("   \u8D26\u53F7");
		textField_2.setBounds(55, 92, 66, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label = new JLabel("     \u5BA0\u7269\u5546\u5E97");
		label.setForeground(Color.ORANGE);
		label.setEnabled(false);
		label.setBackground(Color.GREEN);
		label.setFont(new Font("��Բ", Font.PLAIN, 17));
		label.setBounds(135, 21, 156, 39);
		contentPane.add(label);
		
		textField_1 = new JTextField();
		textField_1.setText("   \u5BC6\u7801");
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(55, 125, 66, 21);
		contentPane.add(textField_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(132, 125, 159, 21);
		contentPane.add(passwordField);
	}
	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==button_1)
		{
		this.dispose();//�����ťʱframe1����,newһ��frame2
		newregister=new Register2014302580073();
		newregister.run();
		}
		if(e.getSource()==button)
		{
			id=textField.getText();
			password=passwordField.getText();
			if(Customer.userservice.login(id,password))
			{
				String msg="��½�ɹ�";
				String title="��ʾ";
				JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
				sellpage=new SellPage2014302580073();
				sellpage.run();
			}
			else{
				String msg="�û������������";
				String title="��ʾ";
				JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
}
