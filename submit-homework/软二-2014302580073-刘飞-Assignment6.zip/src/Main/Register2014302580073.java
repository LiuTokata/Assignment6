package Main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Customer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.mail.MessagingException;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class Register2014302580073 extends JFrame implements ActionListener{

	private JPanel contentPane;
    private JButton btnNewButton;
    private String name;
    private String sex;
    private String phone;
    private String email;
    private String iid;
    private int account;
    private String password;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4;
    private JTextField textField_5;
    private JTextField textField_6;
	/**
	 * Launch the application.
	 */
	
		
			public void run() 
			{
				try 
				{
					Register2014302580073 frame = new Register2014302580073();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			
		
	

	/**
	 * Create the frame.
	 */
	public Register2014302580073() {
		textField = new JTextField();
		textField_1= new JTextField();
		textField_2=new JTextField();
		textField_3= new JTextField();
		textField_4= new JTextField();
	    textField_5= new JTextField();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u6CE8\u518C\u754C\u9762");
		label.setFont(new Font("����", Font.PLAIN, 17));
		label.setBounds(10, 10, 74, 34);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setBounds(10, 67, 54, 15);
		contentPane.add(label_1);
		
		//textField = new JTextField();
		textField.setBounds(40, 64, 66, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label_2 = new JLabel("\u6027\u522B");
		label_2.setBounds(10, 104, 54, 15);
		contentPane.add(label_2);
		
		//textField_1 = new JTextField();
		textField_1.setBounds(40, 101, 66, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblShengfenzheng = new JLabel("\u624B\u673A\u53F7");
		lblShengfenzheng.setBounds(0, 140, 54, 15);
		contentPane.add(lblShengfenzheng);
		
		//textField_2 = new JTextField();
		textField_2.setBounds(40, 137, 66, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label_4 = new JLabel("\u90AE\u7BB1");
		label_4.setBounds(141, 67, 54, 15);
		contentPane.add(label_4);
		
		//textField_3 = new JTextField();
		textField_3.setBounds(180, 64, 172, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel label_5 = new JLabel("\u8D44\u4EA7\uFF08\u5143\uFF09");
		label_5.setBounds(116, 140, 68, 15);
		contentPane.add(label_5);
		
		//textField_4 = new JTextField();
		textField_4.setBounds(180, 101, 172, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		//textField_5 = new JTextField();
		textField_5.setBounds(180, 137, 66, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		btnNewButton = new JButton("\u786E\u8BA4\u6CE8\u518C");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(153, 204, 93, 23);
		contentPane.add(btnNewButton);
		
		JLabel label_3 = new JLabel("\u8EAB\u4EFD\u8BC1\u53F7");
		label_3.setBounds(116, 104, 54, 15);
		contentPane.add(label_3);
		
		JLabel label_6 = new JLabel("\u5BC6\u7801");
		label_6.setBounds(10, 174, 54, 15);
		contentPane.add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(40, 168, 66, 21);
		contentPane.add(textField_6);
		
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==btnNewButton)
		{
			name = textField.getText();
			sex = textField_1.getText();
			phone=textField_2.getText();
			email=textField_3.getText();
			iid=textField_4.getText();
			password=textField_6.getText();
			while(name==null||sex==null||phone==null||email==null||iid==null||textField_5.getText()==null||password==null)
			{
				String msg="����д������Ϣ";
				String title="��ʾ";
				JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
			}
			account=Integer.parseInt(textField_5.getText());
			Test.customer.setName(name);
			Test.customer.setSex(sex);
			Test.customer.setPhoneNumber(phone);
			Test.customer.setEmail(email);
			Test.customer.setIid(iid);
			Test.customer.setAccount(account);
			Test.customer.setPassword(password);
			//System.out.println("��ǰ�����������֤");
			String msg="��ǰ�����������֤";
			String title="��ʾ";
			JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
			
		try {
			if(Customer.userservice.register(Test.customer))
			{
				msg="ע��ɹ��������ֻ��ż�Ϊ�˺�";
				title="��ʾ";
				JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
				Test.main();
			}
			else
			{
				msg="�����ظ�ע��";
				title="��ʾ";
				JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
			}
			
		} catch (MessagingException e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}
		
		}
	}
}
