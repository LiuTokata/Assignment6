package Main;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Map;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class BuyCartShow2014302580073 extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JButton button; 
	private JButton button_1;
	private JTextArea textArea;
	Map<Integer,Integer> goodlist=Test.customer.getMyCart().getList();
	/**
	 * Launch the application.
	 */
	
			public void run() 
			{
				try 
				{
					BuyCartShow2014302580073 frame = new BuyCartShow2014302580073();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		
	

	/**
	 * Create the frame.
	 */
	public BuyCartShow2014302580073() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textArea = new JTextArea();
		textArea.setEnabled(false);
		textArea.setEditable(false);
		textArea.setBounds(10, 10, 414, 191);
		String message = null;
		for(int j=0;j<12;j++)
		{
			if(goodlist.get(j)!=null)
			{
				
				message=(SellPage2014302580073.petList.get(j).getName())+"  ������   "+goodlist.get(j)+"\n";
				textArea.setText(textArea.getText()+message);
			}
		}
		
		contentPane.add(textArea);
		
		button = new JButton("\u53BB\u7ED3\u7B97");
		button.addActionListener(this);
		button.setBounds(331, 228, 93, 23);
		contentPane.add(button);
		
		button_1 = new JButton("\u8FD4\u56DE\u4E3B\u754C\u9762");
		button_1.addActionListener(this);
		button_1.setBounds(184, 228, 137, 23);
		contentPane.add(button_1);
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==button_1)
		{
		this.dispose();//�����ťʱframe1����,newһ��frame2
		SellPage2014302580073 nsellpage=new SellPage2014302580073();
		nsellpage.run();
		}
		if(e.getSource()==button)
		{
			int goodmoney=0;
			for(int j=0;j<12;j++)
			{
				if(goodlist.get(j)!=null)
				{
					goodmoney+=goodlist.get(j)*(SellPage2014302580073.petList.get(j).getPrice());
				}
			}
			int myaccount=Test.customer.getAccount();
			myaccount-=goodmoney;
			Test.customer.setAccount(myaccount);
			Test.customer.getMyCart().list.clear();
			textArea.setText("");
			String msg="�������Ϊ��"+myaccount;
			String title="��ʾ";
			JOptionPane.showMessageDialog(this.contentPane, msg,title,JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
