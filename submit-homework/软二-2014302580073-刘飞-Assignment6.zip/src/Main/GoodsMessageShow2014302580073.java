package Main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Pet;

import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class GoodsMessageShow2014302580073 extends JFrame implements ActionListener{

	private JPanel contentPane;
	public static Pet pet;
	private JButton btnNewButton_1;
	private JButton btnNewButton;
	private JButton btnNewButton_2;
	private JButton button; 
	private JTextArea textArea; 
	public static int goodsid;
	private JTextField textField;
	/**
	 * Launch the application.
	 */
	
			public void run() {
				try {
					GoodsMessageShow2014302580073 frame = new GoodsMessageShow2014302580073();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

	/**
	 * Create the frame.
	 */
	public GoodsMessageShow2014302580073() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textArea = new JTextArea();
		textArea.setBackground(Color.RED);
		textArea.setEnabled(false);
		textArea.setEditable(false);
		textArea.setBounds(0, 24, 269, 227);
		
		contentPane.add(textArea);
		
		btnNewButton = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(279, 96, 132, 45);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("\u8FD4\u56DE\u4E3B\u754C\u9762");
		btnNewButton_1.addActionListener(this);
		btnNewButton_1.setBounds(279, 151, 132, 45);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("\u524D\u5F80\u8D2D\u7269\u8F66");
		btnNewButton_2.addActionListener(this);
		btnNewButton_2.setBounds(279, 206, 132, 45);
		contentPane.add(btnNewButton_2);
		
		JLabel label = new JLabel("   \u8D2D\u4E70\u6570\u91CF");
		label.setFont(new Font("����", Font.PLAIN, 15));
		label.setBounds(290, 21, 106, 28);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setBounds(279, 59, 132, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u663E\u793A\u5177\u4F53\u4FE1\u606F");
		button.addActionListener(this);
		button.setBounds(0, 0, 269, 23);
		contentPane.add(button);
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==btnNewButton_1)
		{
		this.dispose();//�����ťʱframe1����,newһ��frame2
		SellPage2014302580073 nsellpage=new SellPage2014302580073();
		nsellpage.run();
		}
		if(e.getSource()==btnNewButton)
		{
			int num= Integer.parseInt(textField.getText());
			Test.customer.getMyCart().addGoods(goodsid,num);
		}
		if(e.getSource()==btnNewButton_2)
		{
			this.dispose();
			BuyCartShow2014302580073 cartShow=new BuyCartShow2014302580073();
			cartShow.run();
		}
		if(e.getSource()==button)
		{
			textArea.setText("Name:"+pet.getName()+"\nEat:"+pet.getEat()+"\nDrink:"+pet.getDrink()+"\nLive:"+pet.getLive()+"\nHobby:"+pet.getHobby()+"\nPrice:"+pet.getPrice());
		}
	}
}
