package service.inter;

import java.sql.SQLException;

import javax.mail.MessagingException;

import pojo.Customer;

public interface IUserService extends IBaseService<Customer>{
	public boolean login(String id,String password);
	public boolean register(Customer customer) throws MessagingException, InterruptedException, SQLException;
}
