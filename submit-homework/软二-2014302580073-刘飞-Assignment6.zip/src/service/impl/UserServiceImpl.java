package service.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.mail.MessagingException;
import Main.ConnectSQL;
import pojo.Customer;
import service.inter.IUserService;

public class UserServiceImpl implements IUserService
{
	static ConnectSQL connuser=new ConnectSQL();
	static ArrayList<Customer> user=connuser.readCustomer();

	@Override
	public boolean login(String id,String password) {
		for(int i=0;i<user.size();i++)
		{
			String useid=user.get(i).getPhoneNumber();
			String usepass=user.get(i).getPassword();
			if(String.valueOf(id).equals(String.valueOf(useid))&&
					String.valueOf(password).equals(String.valueOf(usepass)))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean register(Customer customer) throws MessagingException, InterruptedException, SQLException {
		for(int i=0;i<user.size();i++)
		{
			String useid=user.get(i).getPhoneNumber();
			if(String.valueOf(customer.getPhoneNumber()).equals(String.valueOf(useid)))
			{
				return false;
			}
		}
		Thread.sleep(600);
		PreparedStatement ps=null;
		String mess;
		mess="insert into customer(name,sex,tel,email,iid,account) values('"+customer.getName()+"','"+customer.getSex()+"','"+customer.getPhoneNumber()+"','"+customer.getEmail()+"','"+customer.getIid()+"','"+customer.getAccount()+"');";				
		ps=connuser.getConnection().prepareStatement(mess);
	    MailService2014302580073 mail =new MailService2014302580073();
	    mail.connect();
	    mail.send(customer.getEmail(),"������֤","��ظ����������������˻�");
	    for(int i = 0;i<30;i++){
            if(mail.listen())
            {
            	ps.executeUpdate(mess);			
        		ps.close();
                return true;
            }
            System.out.println("waiting for reply");
            Thread.sleep(500);
        }
        System.out.println("time out");
		return false;
	}
	@Override
	public boolean add(Customer e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Customer e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean query(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean queryAll() {
		// TODO Auto-generated method stub
		return false;
	}

}
