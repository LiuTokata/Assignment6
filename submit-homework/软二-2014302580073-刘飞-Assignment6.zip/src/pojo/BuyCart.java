package pojo;

import java.util.HashMap;
import java.util.Map;

public class BuyCart {
	private int id;
	public Map<Integer,Integer> list=new HashMap<Integer,Integer>();//(id,number)

	public int getId() {
		return id;
	}

	public Map<Integer, Integer> getList() {
		return list;
	}

	public void addGoods(int id,int number) {
		this.list.put(id, number);
		
	}
	
}
