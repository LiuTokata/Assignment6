package pojo;

import service.impl.UserServiceImpl;

public class Customer {
	private String password;//id
	private String iid;
	private static int account;
	private String name;
	private String sex;
	private String phoneNumber;
	private String Email;
	private BuyCart myBuyCart=new BuyCart();
	public static UserServiceImpl userservice=new UserServiceImpl();
	
	public void setPassword(String pass)
	{
		this.password=pass;
	}
	public String getPassword() {
		return password;
	}
	public String getIid() {
		return iid;
	}
	public void setIid(String iid) {
		this.iid = iid;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		Customer.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String string) {
		this.phoneNumber = string;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public BuyCart getMyCart() {
		return myBuyCart;
	}
	public void setMyCart(BuyCart myBuyCart) {
		this.myBuyCart = myBuyCart;
	}
	
}
